import os, usecsv
import numpy as np
quest = np.array(usecsv.switch(usecsv.opencsv(('quest.csv'))))
quest[quest >5]
quest[quest>5]  = 5
print(quest)