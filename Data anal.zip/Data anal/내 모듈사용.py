import os, usecsv, re
total = usecsv.opencsv(r"C:\Users\USER\Desktop\코딩파일\Data anal\popSeoul2023.csv")
i = total[1]
print(i)
#
k = [float(re.sub(',' , '', j )) if re.search(r'\d',j) else j for j in i]
print(k)